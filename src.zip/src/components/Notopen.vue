<template>
	<div class="notopen">
		<img src="../assets/images/8.png">
		<p>功能未开放，敬请期待！</p>
	</div>
</template>
<script>
	export default{
		name:'notopen'
	}
</script>
<style scoped>
	.notopen{
		text-align: center;
	}
	img{
		margin-top: 0.6rem;
		margin-bottom: 0.4rem
	}
	p{
		font-size: 0.36rem;
		color: #999;
	}
</style>