export default {
	headShow:(state)=> {
		return state.headShow
	},
	footShow:(state)=>{
		return state.footShow
	},
	title:(state)=>{
		return state.title
	},
	changeTitle:(state)=>{
		return state.changeTitle
	},
	isShowParent:(state)=>{
		return state.ishowParent
	}
}
