export default {
	headShow:true,
	footShow:true,
	title:'首页',
	changeTitle:'',
	ishowParent:true
}